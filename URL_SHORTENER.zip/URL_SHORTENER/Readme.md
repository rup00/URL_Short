### URL Shortener Application

## Tasks

[x] Setup HTTP Web Server
[x] Serve Static Files
[x] Render HTML Files
[x] Database Connection
[x] Authentication (Registration & Login)
[x] Session Handling (Inmemory)
[x] Create Logic For URL Shortening
[] API Call Tracker
[] Frontend - @Rupesh Poonia