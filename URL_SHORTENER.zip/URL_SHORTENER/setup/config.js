const db_data = {
    url : "mongodb+srv://<username>:<password>@urlshorten.fcb1h3c.mongodb.net/?retryWrites=true&w=majority",
    secret : 'mysecretkey'
}

module.exports = db_data;